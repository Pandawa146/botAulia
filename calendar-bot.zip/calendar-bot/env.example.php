<?php
/**
 * Created by PhpStorm.
 * Author: Misha Serenkov
 * Email: mi.serenkov@gmail.com
 * Date: 15.10.2017 23:02
 */

return [
    'TELEGRAM_BOT_TOKEN' => '925651312:AAHT0AT_pZWxplc0Vqi52e7ldKA09f_EHIM',
];